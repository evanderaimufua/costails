package com.example.cmpt370;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.List;

/**
 * Unit testcases for the Ingredient Class
 */
public class IngredientsUnitTest {

    @Test
    /*
     * TCi01
     */
    public void ingredientCreateTest() {
        boolean result = false;
        String name = "Vodka";
        double cost = 30.00;
        long quantity = 200;
        double unit_cost = cost/quantity;
        Ingredient vodka = new Ingredient(name, cost, quantity);
        if (vodka.getName().compareTo(name)==0 & vodka.getCost() == unit_cost){
            result = true;
        }

        assertTrue(result);
    }

    @Test
    /*
     * TCi02
     */
    public void exceptionTestTrue(){
        String name = "impossible";
        double cost = 30.00;
        String errMsg = "Invalid quantity input";
        long quantity = 0;
        try {
            Ingredient ingredient = new Ingredient(name, cost, quantity);
        } catch (Exception e){
            assertEquals(errMsg, e.getMessage());
        }
    }

    @Test
    /*
     * TCi03
     */
    public void exceptionTestFalse(){
        String name = "Vodka";
        double cost = 30.00;
        long quantity = 200;
        try{
            Ingredient vodka = new Ingredient(name, cost, quantity);
        } catch (Exception e){
            fail("Should not throw exception");
        }

    }

    @Test
    /*
     * TCi04
     */
    public void testCostSetter(){
        String name = "Vodka";
        double cost = 30.00;
        long quantity = 200;
        double new_cost = 40.00;
        double unit_cost = new_cost/quantity;

        Ingredient vodka = new Ingredient(name, cost, quantity);
        vodka.setCost(new_cost, quantity);
        assertEquals(unit_cost, vodka.getCost(), 0.01);

    }

    @Test
    /*
     * TCi05
     */
    public void testNameSetter(){
        String name = "Vodka";
        double cost = 30.00;
        long quantity = 200;
        String new_name = "Petrone";

        Ingredient vodka = new Ingredient(name, cost, quantity);
        vodka.setName(new_name);
        assertEquals(vodka.getName(), new_name);

    }

    @Test
    /*
     * TCi06
     */
    public void testCustomIngredientCreate(){
        Ingredient limes = new Ingredient("Lime", 2.0, 5);
        Ingredient sugar = new Ingredient("Sugar", 1.0, 2);
        long quantity = 10;
        try {
            CustomIngredient syrup = new CustomIngredient("Syrup", quantity);
            syrup.addIngredient(limes, 20.0);
            syrup.addIngredient(sugar, 10.0);

        } catch (Exception e){
            fail("Should not throw an exception");
        }
    }

    @Test
    /*
     * TCi07
     */
    public void testCustomIngredientCostCalc(){

        double cost = ((2.0/5)*20.0 + (1.0/2)*10.0)/10;

        Ingredient limes = new Ingredient("Lime", 2.0, 5);
        Ingredient sugar = new Ingredient("Sugar", 1.0, 2);
        long quantity = 10;

        CustomIngredient syrup = new CustomIngredient("Syrup", quantity);
        syrup.addIngredient(limes, 20.0);
        syrup.addIngredient(sugar, 10.0);

        assertEquals(cost, syrup.getCost(), 0.01);


    }

    @Test
    /*
     * TCi08
     */
    public void testEmptyCustomIngredientCostCalc(){

        double cost = 0.0;

        long quantity = 10;

        CustomIngredient syrup = new CustomIngredient("Syrup", quantity);

        assertEquals(cost, syrup.getCost(), 0.01);


    }

    @Test
    /*
     * TCi09
     */
    public void CustomIngredientRemoveTest(){

        double cost = 0.0;

        Ingredient limes = new Ingredient("Lime", 2.0, 5);
        long quantity = 10;

        CustomIngredient syrup = new CustomIngredient("Syrup", quantity);
        syrup.addIngredient(limes, 20.0);
        syrup.removeIngredient("Lime");


        assertEquals(cost, syrup.getCost(), 0.01);

    }

    @Test
    /*
     * TCi10
     */
    public void testCustomIngredientException(){
        long quantity = 0;
        String err = "Invalid Quantity Input";
        try {
            CustomIngredient syrup = new CustomIngredient("Syrup", quantity);
            fail("should throw exception");

        } catch (Exception e){
            assertEquals(err, e.getMessage());
        }
    }
    @Test
    /*
     * TCi11
     */
    public void testCreateRecipe(){
        String name = "New Recipe";

        Recipe newRecipe = new Recipe(name);

        assertEquals(newRecipe.getName(), name);
    }
    @Test
    /*
     * TCi12
     */
    public void testAddIngredientToRecipe() {
        Recipe newRecipe = new Recipe("Test Recipe");
        Ingredient limes = new Ingredient("Lime", 2.0, 5);
        newRecipe.addIngredient(limes, 2);
        List<RecipeMap> IngredientsList =  newRecipe.getIngredients();
        RecipeComponent testLimes = IngredientsList.get(0).getIngredient();
        assertEquals(limes.getName(), testLimes.getName());

    }

    @Test
    /*
     * TCi13
     */
    public void testAddCustomIngredientToRecipe() {
        Recipe newRecipe = new Recipe("Test Recipe");
        CustomIngredient limes = new CustomIngredient("Lime", (long) 2.0);
        newRecipe.addCustomIngredient(limes, 2);
        List<RecipeMap> IngredientsList =  newRecipe.getIngredients();
        RecipeComponent testLimes = IngredientsList.get(0).getIngredient();
        assertEquals(limes.getName(), testLimes.getName());

    }

    @Test
    /*
     * TCi14
     */
    public void testGetActualMenuPrice() {
        Recipe newRecipe = new Recipe("Test Recipe");
        newRecipe.setActualMenuPrice(13.5);
        assertEquals(newRecipe.getActualMenuPrice(), 13.5);
    }

    @Test
    /*
     * TCi15
     */
    public void testGetCalculatedMenuPrice() {
        Recipe newRecipe = new Recipe("Test Recipe");
        newRecipe.setActualMenuPrice(13.5);
        assertEquals(newRecipe.getCalculatedMenuPrice(), 13.5);
    }

    @Test
    /*
     * TCi15
     */
    public void testRecipePriceDifference() {
        Recipe newRecipe = new Recipe("Test Recipe");
        newRecipe.setActualMenuPrice(14.0);
        newRecipe.setCalculatedMenuPrice(13.5);
        assertEquals(newRecipe.getPriceDifference(), 0.5);
    }

    @Test
    /*
     * TCi16
     */
    public void testMenuInitialization() {
        Menu testMenu = new Menu();
        assertEquals(testMenu.getName(), "MENU");
    }

    @Test
    /*
     * TCi17
     */
    public void testAddRecipeToMenu() {
        Menu testMenu = new Menu();
        Recipe newRecipe = new Recipe("Test Recipe");
        testMenu.addRecipe(newRecipe);
        assertEquals(testMenu.getRecipeList().get(0), newRecipe);
    }

    @Test
    /*
     * TCi18
     */
    public void testRemoveRecipeFromMenu() {
        Menu testMenu = new Menu();
        Recipe newRecipe = new Recipe("Test Recipe");
        Recipe newRecipe2 = new Recipe("Test Recipe 2");
        testMenu.addRecipe(newRecipe);
        testMenu.addRecipe(newRecipe2);
        testMenu.removeRecipe("Test Recipe 2");
        assertEquals(testMenu.getRecipeList().get(0), newRecipe);
    }

    @Test
    /*
     * TCi18
     */
    public void testSetCaluclatedMargin() {
        Menu testMenu = new Menu();
        Recipe newRecipe = new Recipe("Test Recipe");
        newRecipe.setActualMenuPrice(14.0);
        newRecipe.setCalculatedMenuPrice(13.5);
        testMenu.setMarginDifference();
    }







}