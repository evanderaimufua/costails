/**
 * Author: Corinn Zieglgansberger
 */

package com.example.cmpt370;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 */
public abstract class DBObject {

    private String id = null;
    private String name = null;
    private boolean dirty = true;

    /**
     * Required zero-argument constructor for reading objects from the database.
     */
    public DBObject() { }

    /**
     * Default constructor for newly-created (not yet in database) objects. The object is created in
     * a "dirty" (not synchronized with database) state.
     * @param name Name of the object
     */
    public DBObject(String name) {
        setName(name);
    }

    /**
     * Finds the type identifier string of the indicated class.
     * @param _class A class that extends DBOject class.
     * @return The type identifier string.
     */
    public static String getTypeFromClass(Class<? extends DBObject> _class) {
        return _class.getName().replaceAll("\\.", "_");
    }

    /**
     * Finds a Class object corresponding to the type identifier string.
     * @param type The type identifier string.
     * @return The corresponding Class object.
     */
    public static Class getClassFromType(String type) {
        try {
            return Class.forName(type.replaceAll("_", "."));
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Invalid data object type");
        }
    }

    /**
     * @return The type identifier string for this object.
     */
    public String getType() {
        return getTypeFromClass(this.getClass());
    }

    /**
     * Sets the id of the object iff it was not previously set, the new id is ignored otherwise.
     * @param id Id of the object.
     */
    public void setId(String id) {
        if (this.id != null) return;
        this.id = id;
    }

    /**
     * @return The id of the object.
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the name of the object iff it was not previously set, the new name is ignored otherwise.
     * @param name Name of the object.
     */
    public void setName(String name) {
        id = String.format("_%d", name.hashCode());
        this.name = name;
    }

    /**
     *
     * @return The name of the object.
     */
    public String getName() {
        return name;
    }

    /**
     * Marks the object as "dirty" (not synchronized with the database). Should be called whenever
     * relevant object attributes are modified.
     */
    protected void setDirty() {
        dirty = true;
    }

    /**
     * Sets the "dirty" flag to the given value
     * @param dirty The value to set.
     */
    protected void setDirty(boolean dirty) {
        this.dirty = dirty;
    }

    /**
      * @return True if the object is "dirty" (not synchronized with the database), false otherwise.
     */
    public boolean isDirty() {
        return dirty;
    }

    /**
     * Defines how the object is serialized (converted to bytes) to the database.
     * @param context Serialization context used for writing data.
     */
    protected abstract void doWrite(DBSerializationContext<DBObject> context);

    /**
     * Writes the object to the database. If the object is not "dirty", i.e. synchronized with the
     * database, this method does nothing.
     */
    public void write() {
        // ignore if not dirty
        if (! dirty) return;

        // create a new serialization context
        DBSerializationContext<DBObject> context = new DBSerializationContext<>();

        // call user-defined serialization
        doWrite(context);

        // add name to context
        context.write("name", name);

        // flush data
        context.flushToDatabase(getType(), id);

        // object no longer dirty
        dirty = false;
    }

    /**
     * Defines how the object is deserialized (converted from bytes) from the database.
     * @param context Serialization context used for reading data.
     */
    protected abstract void doRead(DBSerializationContext<DBObject> context);

    /**
     * Reads the object from the database.
     * @return A DBPromise object.
     */
    public DBPromise<DBObject> read() {
        dirty = true;
        return new DBPromise<>(
                getType(),
                id,
                (context) -> {
                    // read the name
                    setName(context.readString("name"));

                    // call user-defined deserialization
                    doRead(context);

                    // object is now synchronized with the database
                    dirty = false;

                    return this;
                }
        );
    }

    public static <T extends DBObject> DBPromise<List<T>> getAllObjects(Class<T> _class) {
        return new DBPromise<>(
                getTypeFromClass(_class),
                (context) -> {
                    List<T> objs = new LinkedList<>();

                    for (
                            DBSerializationContext<DBObject> ctx = context.nextDataObject();
                            ctx != null;
                            ctx = context.nextDataObject()
                    ) {

                        try {
                            T obj = _class.getConstructor().newInstance();

                            // read the name
                            obj.setName(ctx.readString("name"));

                            // call user-defined deserialization
                            obj.doRead(ctx);

                            // object is now synchronized with the database
                            obj.setDirty(false);

                            objs.add(obj);
                        } catch (IllegalAccessException | InstantiationException | InvocationTargetException | NoSuchMethodException e) {
                            e.printStackTrace();
                        }
                    }

                    return objs;
                }
        );
    }
}

// example data objects
//
//class A extends DBObject {
//
//    String stringAttr;
//    double doubleAttr;
//
//    public A() { }
//
//    public A(String name) {
//        super(name);
//    }
//
//    @Override
//    protected void doWrite(DBSerializationContext<DBObject> context) {
//        context.write("stringAttr", stringAttr);
//        context.write("doubleAttr", doubleAttr);
//    }
//
//    @Override
//    protected void doRead(DBSerializationContext<DBObject> context) {
//        stringAttr = context.readString("stringAttr");
//        doubleAttr = context.readDouble("doubleAttr");
//    }
//
//    public A(String name, String stringAttr, double doubleAttr) {
//        super(name);
//        this.stringAttr = stringAttr;
//        this.doubleAttr = doubleAttr;
//    }
//
//
//    @Override
//    public String toString() {
//        return "A{" +
//                "stringAttr='" + stringAttr + '\'' +
//                ", doubleAttr=" + doubleAttr +
//                '}';
//    }
//}
//
//class B extends A {
//    int intAttr;
//
//    public B() { }
//
//    public B(String name) {
//        super(name);
//    }
//
//    public B(String name, String stringAttr, double doubleAttr, int intAttr) {
//        super(name, stringAttr, doubleAttr);
//        this.intAttr = intAttr;
//    }
//
//    @Override
//    protected void doWrite(DBSerializationContext<DBObject> context) {
//        super.doWrite(context);
//        context.write("intAttr", intAttr);
//    }
//
//    @Override
//    protected void doRead(DBSerializationContext<DBObject> context) {
//        super.doRead(context);
//        intAttr = context.readInt("intAttr");
//    }
//
//    @Override
//    public String toString() {
//        return "B{" +
//                "stringAttr='" + stringAttr + '\'' +
//                ", doubleAttr=" + doubleAttr +
//                ", intAttr=" + intAttr +
//                '}';
//    }
//}
//
//class C extends DBObject {
//
//    A a;
//    List<A> as;
//    B b;
//    List<B> bs;
//    boolean booleanAttr;
//
//    public C() { }
//
//    public C(String name) {
//        super(name);
//    }
//
//    @Override
//    protected void doWrite(DBSerializationContext<DBObject> context) {
//        context.write("a", a);
//        context.write("as", as);
//        context.write("b", b);
//        context.write("bs", bs);
//        context.write("booleanAttr", booleanAttr);
//    }
//
//    @Override
//    protected void doRead(DBSerializationContext<DBObject> context) {
//        a = context.readObject("a");
//        as = context.readObjectList("as");
//        b = context.readObject("b");
//        bs = context.readObjectList("bs");
//        booleanAttr = context.readBoolean("booleanAttr");
//    }
//
//    public C(String name, A a, List<A> as, B b, List<B> bs, boolean booleanAttr) {
//        super(name);
//        this.a = a;
//        this.as = as;
//        this.b = b;
//        this.bs = bs;
//        this.booleanAttr = booleanAttr;
//    }
//
//    @Override
//    public String toString() {
//        return "C{" +
//                "a=" + a +
//                ", as=" + as +
//                ", b=" + b +
//                ", bs=" + bs +
//                ", booleanAttr=" + booleanAttr +
//                '}';
//    }
//}
