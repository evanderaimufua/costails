package com.example.cmpt370;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Author: Jessi
 * The class responsible for generating a selectable list of ingredients/custom ingredients for a user to browse. Used to
 * add ingredients to recipes (see RecipeAddFragment)
 *
 * Selected ingredients are passed between fragments using Android Bundles
 */
public class BrowseRecipeFragment extends androidx.fragment.app.Fragment {
    private RecyclerView mRecyclerView;
    private IngredientCompAdapter adapter;
    private ArrayList<RecipeComponent> ingredientList;
    private EditText amount_box;
    private Button add;
    private NavController navCntrl;
    private ArrayList<String> names, costs, amounts;

    public BrowseRecipeFragment() {
        // Required empty public constructor
    }

   /* @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_browse_recipe, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize the recycler veiw and populate it with ingredients to select
        mRecyclerView = view.findViewById(R.id.recyclerview_ingredients);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        ingredientList = new ArrayList<>();

        adapter = new IngredientCompAdapter(view.getContext(), ingredientList, true);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setHasFixedSize(true);
        //read all objects from DB
        DBObject.getAllObjects(Ingredient.class).then(objs -> {
            for (Ingredient x : objs) ingredientList.add(x);
            adapter.notifyDataSetChanged();
        });

        DBObject.getAllObjects(CustomIngredient.class).then(objs -> {
            for (CustomIngredient x : objs) ingredientList.add(x);
            adapter.notifyDataSetChanged();
        });



        //set up button and input text box
        add = view.findViewById(R.id.addto);
        amount_box = view.findViewById(R.id.amountbox);

        add.setOnClickListener(this::OnClick_returnSelected);

        if(getArguments() != null) {
            names = getArguments().getStringArrayList("names");
            costs = getArguments().getStringArrayList("cost");
            amounts = getArguments().getStringArrayList("amount");
        }
    }

    public void OnClick_returnSelected(View view){
        RecipeComponent selected = adapter.getSelected();
        String amount = amount_box.getText().toString();
        Bundle bundle = new Bundle();
        names.add(selected.getName());
        costs.add(String.valueOf(selected.getCost()));
        amounts.add(amount);
        bundle.putStringArrayList("names", names);
        bundle.putStringArrayList("costs", costs);
        bundle.putStringArrayList("amounts", amounts);


        navCntrl = Navigation.findNavController(view);
        navCntrl.navigate(R.id.browsetoAddCustom, bundle);



    }
}