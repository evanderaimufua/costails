package com.example.cmpt370;


public abstract class RecipeComponent extends DBObject {
    public RecipeComponent() {
    }

    public RecipeComponent(String name) {
        super(name);
    }

    // interface methods for all recipe components

    abstract double getCost();

}
