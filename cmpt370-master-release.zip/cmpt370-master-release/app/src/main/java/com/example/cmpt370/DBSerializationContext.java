/**
 * Author: Corinn Zieglgansberger
 */

package com.example.cmpt370;

import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class DBSerializationContext<T> {
    private DBObjectInitializer<T> initializer = null;
    private DBVoidCallback<T> callback = null;
    private Map<String, Object> data = null;
    private T initializedObject = null;
    private DBSerializationContext parent = null;

    private List<DBPromise<DBObject>> children = new LinkedList<>();
    private int numOutstandingChildren = 0;

    // for writing
    public DBSerializationContext() {
        this.data = new HashMap<>();
    }

    // for reading
    public DBSerializationContext(
            DBObjectInitializer<T> initializer,
            DBVoidCallback<T> callback
    ) {
        this.initializer = initializer;
        this.callback = callback;
    }

    private DBSerializationContext(Map<String, Object> data, DBSerializationContext parent) {
        this.data = data;
        this.parent = parent;
    }

    synchronized private void addChildPromise(DBPromise<DBObject> promise) {
        if (parent != null) {
            parent.addChildPromise(promise);
        }
        else {
            children.add(promise);
            ++numOutstandingChildren;
        }
    }

    synchronized private void childPromiseDone() {
        --numOutstandingChildren;
        if (numOutstandingChildren == 0) {
            children.clear();
            callback.run(initializedObject);
        }
    }

    OnCompleteListener<DataSnapshot> getListener() {
        if (callback == null || initializer == null) {
            throw new RuntimeException("DBSerializationContext not prepared for reading");
        }

        return task -> {
            if (!task.isSuccessful()) {
                Log.e("firebase", "Error getting data", task.getException());
            }
            else {
                Object obj = task.getResult().getValue();
                if (! (obj instanceof Map)) {
                    throw new RuntimeException("Unexpected data returned");
                }

                data = (Map<String, Object>) obj;

                initializedObject = initializer.run(DBSerializationContext.this);
                if (children.isEmpty()) {
                    callback.run(initializedObject);
                }
                else {
                    for (DBPromise<DBObject> child : children) {
                        child.then(ignored -> childPromiseDone());
                    }
                }
            }
        };
    }

    void flushToDatabase(String type, String id) {
        DatabaseReference root = FirebaseDatabase.getInstance().getReference();
        root.child(type).child(id).setValue(data);
    }

    public DBSerializationContext<DBObject> nextDataObject() {

        if (data == null || data.isEmpty()) return null;

        Object obj = data.remove(data.entrySet().iterator().next().getKey());
        if (! (obj instanceof Map)) {
            throw new RuntimeException("Unexpected data returned");
        }
        return new DBSerializationContext<>((Map<String, Object>) obj, this);
    }

    public DBSerializationContext<T> write(String name, String str) {
        data.put(name, str);
        return this;
    }

    public DBSerializationContext<T> write(String name, long val) {
        data.put(name, val);
        return this;
    }

    public DBSerializationContext<T> write(String name, double val) {
        data.put(name, val);
        return this;
    }

    public DBSerializationContext<T> write(String name, boolean val) {
        data.put(name, val);
        return this;
    }

    private HashMap<String, Object> writeObjectReference(DBObject obj) {
        // check if the object is in the database, write if not exists
        if (obj.isDirty()) {
            obj.write();
        }
        else {
            DatabaseReference root = FirebaseDatabase.getInstance().getReference();
            root.child(obj.getType()).child(obj.getId())
                    .get()
                    .addOnCompleteListener(task -> {
                                if (! task.isSuccessful()) {
                                    Log.e("firebase", "Error getting data", task.getException());
                                }
                                else if (task.getResult().getValue() == null) {
                                    obj.write();
                                }
                            }
                    );
        }

        // create the reference
        HashMap<String, Object> data = new HashMap<>();
        data.put("type", obj.getType());
        data.put("id", obj.getId());
        return data;
    }

    public DBSerializationContext<T> write(String name, DBObject obj) {
        data.put(name, writeObjectReference(obj));
        return this;
    }

    public DBSerializationContext<T> write(String name, List<? extends DBObject> objects) {
        List<Object> list = new ArrayList<>(objects.size());
        for (DBObject obj : objects) {
            list.add(writeObjectReference(obj));
        }
        data.put(name, list);
        return this;
    }

    public String readString(String name) {
        Object obj = data.get(name);
        if (obj instanceof String) {
            return (String) data.get(name);
        }
        else {
            throw new RuntimeException("Incompatible type found");
        }
    }

    public int readInt(String name) {
        Object obj = data.get(name);
        if (obj instanceof Long) {
            return ((Long) data.get(name)).intValue();
        }
        else if (obj instanceof Double) {
            return ((Double) data.get(name)).intValue();
        }
        else {
            throw new RuntimeException("Incompatible type found");
        }
    }

    public long readLong(String name) {
        Object obj = data.get(name);
        if (obj instanceof Long) {
            return ((Long) data.get(name)).longValue();
        }
        else if (obj instanceof Double) {
            return ((Double) data.get(name)).longValue();
        }
        else {
            throw new RuntimeException("Incompatible type found");
        }
    }

    public float readFloat(String name) {
        Object obj = data.get(name);
        if (obj instanceof Long) {
            return ((Long) data.get(name)).floatValue();
        }
        else if (obj instanceof Double) {
            return ((Double) data.get(name)).floatValue();
        }
        else {
            throw new RuntimeException("Incompatible type found");
        }
    }

    public double readDouble(String name) {
        Object obj = data.get(name);
        if (obj instanceof Long) {
            return ((Long) data.get(name)).doubleValue();
        }
        else if (obj instanceof Double) {
            return ((Double) data.get(name)).doubleValue();
        }
        else {
            throw new RuntimeException("Incompatible type found");
        }
    }

    public boolean readBoolean(String name) {
        Object obj = data.get(name);
        if (obj instanceof Boolean) {
            return ((Boolean) data.get(name)).booleanValue();
        }
        else {
            throw new RuntimeException("Incompatible type found");
        }
    }

    private DBObject readObjectReference(Object ref) {
        if (! (ref instanceof Map)) {
            throw new RuntimeException("Unexpected data");
        }

        Map<String, Object> refData = (Map<String, Object>) ref;

        try {
            DBObject obj = (DBObject) DBObject.getClassFromType((String) refData.get("type")).getConstructor().newInstance();
            obj.setId((String) refData.get("id"));
            return obj;
        } catch (NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e) {
            throw new RuntimeException("Invalid data object type");
        }
    }

    public <U extends DBObject> U readObject(String name) {
        U obj = (U) readObjectReference(data.get(name));
        addChildPromise(obj.read());
        return obj;
    }

    public <U extends DBObject> List<U> readObjectList(String name) {
        Object list = data.get(name);
        if (! (list instanceof List)) {
            throw new RuntimeException("Unexpected data");
        }

        List<Object> refs = (List<Object>) list;
        List<U> objs = new ArrayList<>(refs.size());

        for (Object ref : refs) {
            U obj = (U) readObjectReference(ref);
            objs.add(obj);
            addChildPromise(obj.read());
        }

        return objs;
    }
}
