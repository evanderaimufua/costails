package com.example.cmpt370;

public class CustomIngredient extends IngredientContainer{

    private long quantity;
    /**
     * Constructors to initialize
     *
     */
    public CustomIngredient(){
        super();
    }

    public CustomIngredient(String namein, long quantity) throws RuntimeException{
        super(namein);
        if (quantity <= 0){
            throw new RuntimeException("Invalid Quantity Input");
        }
        this.quantity = quantity;
    }

    @Override
    protected void doWrite(DBSerializationContext<DBObject> context) {
        super.doWrite(context);
        context.write("quantity", quantity);
    }

    @Override
    protected void doRead(DBSerializationContext<DBObject> context) {
        super.doRead(context);
        quantity = context.readLong("quantity");
    }

    /**
     * Overriden method to return unit cost for custom ingredient
     * @return the unit cost per custom ingredient
     */
    @Override
    public double getCost() {
        double cost = super.getCost();
        return (cost/this.quantity);
    }
}
