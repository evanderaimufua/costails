package com.example.cmpt370;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.navigation.ui.NavigationViewKt;

import com.example.cmpt370.databinding.ActivityHomeBinding;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.FirebaseDatabase;

import android.util.Log;


import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    //Variables for navigationbar
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        //set the content view to the activity home page
        setContentView(R.layout.activity_home);
        /*Code for navigationView functionality
         *
         */
        //Connecting layout--------------------------------
        drawerLayout = findViewById(R.id.homepage);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);
        //Toolbar----------------------------------
        setSupportActionBar(toolbar);
        //Navigation draw menu----------------------
        navigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);




        //initialize firebase
        FirebaseApp.initializeApp(this);
//
//        A a = new A("a_instance_1", "my string", 123.4);
//        a.write();
//
//        B b = new B("b_instance_1", "my other string", 1234.5, 321);
//        b.write();
//
//        List<A> as = new ArrayList<>();
//        as.add(new A("a_instance_3", "ai3", 4764));
//        as.add(new A("a_instance_4", "ai4", 64));
//
//        List<B> bs = new ArrayList<>();
//        bs.add(new B("b_instance_3", "bi3", 4764, 332));
//        bs.add(new B("B_instance_4", "bi4", 64.5, 67));
//
//        C c = new C(
//                "c_instance_1",
//                new A("a_instance_2", "another string", 456.7),
//                as,
//                new B("b_instance_2", "yet another string", 4334.4, 222),
//                bs,
//                true
//        );
//        c.write();

//        C c = new C("c_instance_1");
//        c.read().then(x -> Log.i("test", x.toString()));
    }

    public void OnClick_addIngredient(View view){
        Intent newPage = new Intent(this, Ingredient_Interface.class);
        startActivity(newPage);
    }

    public void OnClick_dispIngredients(View view){
        //In future, open the display ingredients page. As we don't have one yet, we just... wont.
        Intent newPage = new Intent(this, IngredientsList.class);
        startActivity(newPage);

    }


    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else{
        super.onBackPressed();
        }
    }



    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.nav_home:
                break;
            case R.id.nav_add:
                Intent intent = new Intent(HomeActivity.this,Ingredient_Interface.class);
                startActivity(intent);
                break;
            case R.id.nav_menu:
                Intent intent2 = new Intent(HomeActivity.this,Menu.class);
                startActivity(intent2);
                break;
            case R.id.nav_recipe:
                Intent intent3 = new Intent(HomeActivity.this,Recipe.class);
                startActivity(intent3);
            case R.id.logout:
                break;
        }
        return true;
    }


    public void OnClick_addCustom(View view){
        Intent newPage = new Intent(this, CustomAddActivity.class);
        startActivity(newPage);
    }

    public void OnClick_addRecipe(View view){
        Intent newPage = new Intent(this, RecipeAddActivity.class);
        startActivity(newPage);
    }

    public void OnClick_addMenu(View view){
        Intent newPage = new Intent(this, MenuAddActivity.class);
        startActivity(newPage);
    }

    public void OnClick_dispRecipe(View view){
        Intent newPage = new Intent(this, RecipeList.class);
        startActivity(newPage);
    }

    public void OnClick_dispMenu(View view){
        Intent newPage = new Intent(this, MenuList.class);
        startActivity(newPage);
    }
}