package com.example.cmpt370;

import java.util.ArrayList;
import java.util.List;

public class IngredientContainer extends RecipeComponent {
    private Double cost = null;
    private List<RecipeMap> ingredients = new ArrayList<>();


    public IngredientContainer() {
    }

    public IngredientContainer(String name) {
        super(name);
    }

    @Override
    protected void doWrite(DBSerializationContext<DBObject> context) {
        context.write("ingredients", ingredients);
    }

    @Override
    protected void doRead(DBSerializationContext<DBObject> context) {
        ingredients = context.readObjectList("ingredients");
        cost = null;
    }

    /**
     * Adds an ingredient to the container
     * @param ingredient ingredient object to be added
     * @param amount amount of the ingredient, in mL
     */
    public void addIngredient(RecipeComponent ingredient, double amount){
        ingredients.add(new RecipeMap(ingredient, amount));
        cost = null;
    }

    public void addIngredients(List<RecipeMap> ingredientsList){
        ingredients.addAll(ingredientsList);
    }

    /**
     * removes an ingredient from the container by name.
     * @param name name of the ingredient
     * @return 0 on success, a -1 on failure
     */
    public int removeIngredient(String name){
        int removal_index = -1;
        //loop through ingredients to find ingredient by name
        for (int i = 0; i < ingredients.size(); i++) {
            //if found, set the index of the ingredient in the array and break the loop
            if (ingredients.get(i).getIngredient().getName().equals(name)) {
                removal_index = i;
                break;
            }
        }

        //if a removal index was found, remove the ingredient
        //otherwise, do nothing
        if (removal_index >= 0){
            ingredients.remove(removal_index);
            //indicate that the ingredient has been modified
            cost = null;
            setDirty();
            return 0;

        }

        //if the item wasn't removed, return an error
        return -1;

    }

    /**
     * Public method to change the quantity amount of an ingredient in a recipe
     * @param name the name of the ingredient that you would like to change
     * @param newAmount A new volume quantity of an ingredient
     */
    public void changeAmount(String name, double newAmount){
        for (int i = 0; i < ingredients.size(); i++){
            if (ingredients.get(i).getIngredient().getName().equals(name)){
                ingredients.get(i).setQuantity(newAmount);
            }
        }
        //indicate that the component has been modified
        cost = null;
        setDirty();
    }


    /**
     * Calculates the sum of the cost of the ingredient in a container.
     * If the container has not been modified since the last time
     * calculateCost() was called, it simple returns the same cost as
     * calculated previously.
     */
    private void calculateCost(){
        if (cost == null) { //only recalculates the cost if it has been modified since last call
            double temp = 0.0;

            for (int i = 0; i < ingredients.size(); i++) {
                temp += ingredients.get(i).getQuantity() * ingredients.get(i).getIngredient().getCost();
            }
            cost = temp;
        }

    }

    // Getters and setters for values

    /**
     * @return the total cost of the ingredient's and custom ingredients in a recipe
     * Will only calculate the cost if it has been modified
     */
    public double getCost(){
        calculateCost();
        return this.cost;
    }

    public List<RecipeMap> getIngredients() {
        return ingredients;
    }

}
