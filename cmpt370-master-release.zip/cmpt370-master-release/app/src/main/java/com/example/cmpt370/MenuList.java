package com.example.cmpt370;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MenuList extends AppCompatActivity {

    private RecyclerView mRecylcerView;
    private RecipeAdapter adapter;
    private ArrayList<Recipe> menuList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_list);
        mRecylcerView = findViewById(R.id.recyclerview_menu);
        mRecylcerView.setLayoutManager(new LinearLayoutManager(this));
        menuList = new ArrayList<>();
        adapter = new RecipeAdapter(this, menuList, false);
        mRecylcerView.setAdapter(adapter);

        //* .add(x) is causing and error
        /*//read all objects from database
        DBObject.getAllObjects(Menu.class).then(objs -> {
            for (Menu x : objs) menuList.add(x);
            adapter.notifyDataSetChanged();
        });*/

    }
}
