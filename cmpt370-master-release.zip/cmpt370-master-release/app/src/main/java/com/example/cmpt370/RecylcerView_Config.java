package com.example.cmpt370;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
//class is responsible for creating IngredientItemView
// passing ingredient object and key to bind method
class IngredientsAdapter extends RecyclerView.Adapter<IngredientsAdapter.IngredientItemView>{
    private Context mContext;
    private List<Ingredient> mIngredientList;
    private boolean setClickable;
    private int selectedPostition;
    private  Ingredient selected;
    //private List<String> mKeys;

    public IngredientsAdapter(Context mContext, List<Ingredient> mIngredientList, boolean clickable) {
        this.mContext = mContext;
        this.mIngredientList = mIngredientList;
        setClickable = clickable;
        selectedPostition = -1;
        selected = null;
        //this.mKeys = mKeys;
    }

    @NonNull
    @Override
    public IngredientItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.ingredient_list_item, parent, false);
        return new IngredientItemView(v, this.setClickable);
    }

    @Override
    public void onBindViewHolder(@NonNull IngredientItemView holder, int position) {
        holder.bind(mIngredientList.get(position));

    }

    //return the size of ingredient list
    @Override
    public int getItemCount() {
        return mIngredientList.size();
    }

    protected void setSelectedPosition(int position){
        selectedPostition = position;
    }

    protected int getSelectedPosition(){
        return selectedPostition;
    }

    protected void setSelected(int index){
        selected = mIngredientList.get(index);
        //set prev veiw
    }
    public Ingredient getSelected(){
        selectedPostition = -1;
        return selected;
    }

    // Responsible for inflating the layout Ingredient_list_item and populating its view objects
    public static class IngredientItemView extends RecyclerView.ViewHolder{
        private TextView mName;
        private TextView mCost;
        private View view;

        //Define string variable for holding the key for ingredients
       // private String key;

        //Constructor
        //override the parent constructor and give it the inflated layout
        public IngredientItemView(@NonNull View parent, boolean clickable){
            super(parent);
            //Initialize the text fields from the inflated layout
            mName = parent.findViewById(R.id.name_txtView);
            mCost = parent.findViewById(R.id.cost_txtview);
            view = parent;

            if(clickable){
                parent.setOnClickListener(this::clicked);
            }

        }
        //populate text views from the ingredients object
        public void bind(Ingredient ingredient){
            IngredientsAdapter a = (IngredientsAdapter) getBindingAdapter();
            int selected = a.getSelectedPosition();
            mName.setText(ingredient.getName());;
            mCost.setText(String.valueOf(ingredient.getCost()));
            if (getBindingAdapterPosition() != selected){
                view.setBackgroundResource(R.drawable.ingredientlistbox);
            }
            //this.key = key;
        }

        protected void clicked(View view){
            IngredientsAdapter a = (IngredientsAdapter) getBindingAdapter();
            int prev_position = a.getSelectedPosition();
            int position = this.getBindingAdapterPosition();
            a.setSelectedPosition(position);
            a.setSelected(position);
            view.setBackgroundColor(-20);
            a.notifyItemChanged(prev_position);

        }

    }
}




class RecipeMapAdapter extends RecyclerView.Adapter<RecipeMapAdapter.RecipeMapView>{
    private Context mContext;
    private List<RecipeMap> mRecipeMapList;
    //private List<String> mKeys;

    public RecipeMapAdapter(Context mContext, List<RecipeMap> mRList) {
        this.mContext = mContext;
        this.mRecipeMapList = mRList;
        //this.mKeys = mKeys;
    }

    @NonNull
    @Override
    public RecipeMapView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.recipemap_list_item, parent, false);
        return new RecipeMapView(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecipeMapView holder, int position) {
        holder.bind(mRecipeMapList.get(position));
    }


    //return the size of ingredient list
    @Override
    public int getItemCount() {
        return mRecipeMapList.size();
    }

    // Responsible for inflating the layout Ingredient_list_item and populating its view objects
    public static class RecipeMapView extends RecyclerView.ViewHolder{
        private TextView mName;
        private TextView mAmount;

        //Define string variable for holding the key for ingredients
        // private String key;

        //Constructor
        //override the parent constructor and give it the inflated layout
        public RecipeMapView(@NonNull View itemView) {
            super(itemView);

            //Initialize the text fields from the inflated layout
            mName = itemView.findViewById(R.id.name_txtView);
            mAmount = itemView.findViewById(R.id.amount_txtview);
        }

        //populate text views from the ingredients object
        public void bind(RecipeMap rmap){
            mName.setText(rmap.getIngredient().getName());;
            mAmount.setText(String.valueOf(rmap.getQuantity()));
            //this.key = key;
        }

    }
}


class IngredientCompAdapter extends RecyclerView.Adapter<IngredientCompAdapter.IngredientItemView>{
    private Context mContext;
    private List<RecipeComponent> mIngredientList;
    private boolean setClickable;
    private int selectedPostition;
    private  RecipeComponent selected;
    //private List<String> mKeys;

    public IngredientCompAdapter(Context mContext, List<RecipeComponent> mIngredientList, boolean clickable) {
        this.mContext = mContext;
        this.mIngredientList = mIngredientList;
        setClickable = clickable;
        selectedPostition = -1;
        selected = null;
        //this.mKeys = mKeys;
    }

    @NonNull
    @Override
    public IngredientItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.ingredient_list_item, parent, false);
        return new IngredientItemView(v, this.setClickable);
    }

    @Override
    public void onBindViewHolder(@NonNull IngredientItemView holder, int position) {
        holder.bind(mIngredientList.get(position));

    }

    //return the size of ingredient list
    @Override
    public int getItemCount() {
        return mIngredientList.size();
    }

    protected void setSelectedPosition(int position){
        selectedPostition = position;
    }

    protected int getSelectedPosition(){
        return selectedPostition;
    }

    protected void setSelected(int index){
        selected = mIngredientList.get(index);
        //set prev veiw
    }
    public RecipeComponent getSelected(){
        selectedPostition = -1;
        return selected;
    }

    // Responsible for inflating the layout Ingredient_list_item and populating its view objects
    public static class IngredientItemView extends RecyclerView.ViewHolder{
        private TextView mName;
        private TextView mCost;
        private View view;

        //Define string variable for holding the key for ingredients
        // private String key;

        //Constructor
        //override the parent constructor and give it the inflated layout
        public IngredientItemView(@NonNull View parent, boolean clickable){
            super(parent);
            //Initialize the text fields from the inflated layout
            mName = parent.findViewById(R.id.name_txtView);
            mCost = parent.findViewById(R.id.cost_txtview);
            view = parent;

            if(clickable){
                parent.setOnClickListener(this::clicked);
            }

        }
        //populate text views from the ingredients object
        public void bind(RecipeComponent ingredient){
            IngredientCompAdapter a = (IngredientCompAdapter) getBindingAdapter();
            int selected = a.getSelectedPosition();
            mName.setText(ingredient.getName());;
            mCost.setText(String.valueOf(ingredient.getCost()));
            if (getBindingAdapterPosition() != selected){
                view.setBackgroundResource(R.drawable.ingredientlistbox);
            }
            //this.key = key;
        }

        protected void clicked(View view){
            IngredientCompAdapter a = (IngredientCompAdapter) getBindingAdapter();
            int prev_position = a.getSelectedPosition();
            int position = this.getBindingAdapterPosition();
            a.setSelectedPosition(position);
            a.setSelected(position);
            view.setBackgroundColor(-20);
            a.notifyItemChanged(prev_position);

        }

    }
}


class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.RecipeItemView>{
    private Context mContext;
    private List<Recipe> recipeList;
    private boolean setClickable;
    private int selectedPostition;
    private  Recipe selected;
    //private List<String> mKeys;

    public RecipeAdapter(Context mContext, List<Recipe> recipeList, boolean clickable) {
        this.mContext = mContext;
        this.recipeList = recipeList;
        setClickable = clickable;
        selectedPostition = -1;
        selected = null;
        //this.mKeys = mKeys;
    }

    @NonNull
    @Override
    public RecipeItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.recipe_list_item, parent, false);
        return new RecipeItemView(v, this.setClickable);
    }

    @Override
    public void onBindViewHolder(@NonNull RecipeItemView holder, int position) {
        holder.bind(recipeList.get(position));

    }

    //return the size of ingredient list
    @Override
    public int getItemCount() {
        return recipeList.size();
    }

    protected void setSelectedPosition(int position){
        selectedPostition = position;
    }

    protected int getSelectedPosition(){
        return selectedPostition;
    }

    protected void setSelected(int index){
        selected = recipeList.get(index);
        //set prev veiw
    }
    public Recipe getSelected(){
        selectedPostition = -1;
        return selected;
    }

    // Responsible for inflating the layout Ingredient_list_item and populating its view objects
    public static class RecipeItemView extends RecyclerView.ViewHolder{
        private TextView mName;
        private TextView mCost;
        private TextView mRecCost;
        private View view;

        //Define string variable for holding the key for ingredients
        // private String key;

        //Constructor
        //override the parent constructor and give it the inflated layout
        public RecipeItemView(@NonNull View parent, boolean clickable){
            super(parent);
            //Initialize the text fields from the inflated layout
            mName = parent.findViewById(R.id.name_txtView);
            mCost = parent.findViewById(R.id.actualcost_txtview);
            mRecCost = parent.findViewById(R.id.calccost_txtView2);
            view = parent;

            if(clickable){
                parent.setOnClickListener(this::clicked);
            }

        }
        //populate text views from the ingredients object
        public void bind(Recipe recipe){
            RecipeAdapter a = (RecipeAdapter) getBindingAdapter();
            int selected = a.getSelectedPosition();
            mName.setText(recipe.getName());;
            mCost.setText(String.valueOf(recipe.getActualMenuPrice()));
            mRecCost.setText(String.valueOf(recipe.getCalculatedMenuPrice()));
            if (getBindingAdapterPosition() != selected){
                view.setBackgroundResource(R.drawable.ingredientlistbox);
            }
            //this.key = key;
        }

        protected void clicked(View view){
            RecipeAdapter a = (RecipeAdapter) getBindingAdapter();
            int prev_position = a.getSelectedPosition();
            int position = this.getBindingAdapterPosition();
            a.setSelectedPosition(position);
            a.setSelected(position);
            view.setBackgroundColor(-20);
            a.notifyItemChanged(prev_position);

        }

    }
}


