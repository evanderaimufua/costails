package com.example.cmpt370;

public class RecipeMap extends DBObject {

    private RecipeComponent ingredient;
    private double quantity;

    public RecipeMap() {
    }

    public RecipeMap(String name) {
        super(name);
    }

    public RecipeMap(RecipeComponent ingredient, double quantity) {
        super(ingredient.getName());
        this.ingredient = ingredient;
        this.quantity = quantity;
    }


    @Override
    protected void doWrite(DBSerializationContext<DBObject> context) {
        context.write("ingredient", ingredient);
        context.write("quantity", quantity);
    }

    @Override
    protected void doRead(DBSerializationContext<DBObject> context) {
        ingredient = context.readObject("ingredient");
        quantity = context.readDouble("quantity");
    }

    public void setIngredient(RecipeComponent ingredient) {
        this.ingredient = ingredient;
    }

    public void setQuantity(double quantity){
        this.quantity = quantity;
    }

    public RecipeComponent getIngredient(){
        return this.ingredient;
    }

    public double getQuantity(){
        return this.quantity;
    }


}
