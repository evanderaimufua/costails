/**
 * Activity page for adding an ingredient to the database
 * Authors: Anuj, Jessi
 * Sets a new activity page, takes input from the user
 * and uses input to put an ingredient in the db
 *
 * TODO: what happens if the user inputs something invalid?
 */
package com.example.cmpt370;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.navigation.NavigationView;

public class Ingredient_Interface extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private EditText name, amount, cost;
    //Variables for navigationbar
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredient_interface);

        //extract user input from the xml layout input fields
        //see res/layout/activity_ingredient_interface
        name = findViewById(R.id.edit_id1);
        cost = findViewById(R.id.edit_id2);
        amount = findViewById(R.id.edit_id3);

        //Connecting layout--------------------------------
        drawerLayout = findViewById(R.id.ingredient_view);
        navigationView = findViewById(R.id.nav_view2);
        toolbar = findViewById(R.id.toolbar2);
        //Toolbar----------------------------------
        //setSupportActionBar(toolbar);
        //Navigation draw menu----------------------
        navigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

    }

    public void OnClick_SaveIngredientData(View view) {
        writeNewIngredient();
    }

    private void writeNewIngredient(){
        Ingredient ingredient = new Ingredient(name.getText().toString(),
                Double.parseDouble(String.valueOf(cost.getText())),
                Long.parseLong(String.valueOf(amount.getText())));
        Log.i("ingredient", ingredient.getName());
        ingredient.write();
        Log.i("firebase", "attempted to write");

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.nav_home:
                Intent intent = new Intent(Ingredient_Interface.this,HomeActivity.class);
                startActivity(intent);
                break;
            case R.id.nav_add:
                break;
            case R.id.nav_menu:
                Intent intent2 = new Intent(Ingredient_Interface.this,Menu.class);
                startActivity(intent2);
                break;
            case R.id.nav_recipe:
                Intent intent3 = new Intent(Ingredient_Interface.this,Recipe.class);
                startActivity(intent3);
            case R.id.logout:
                break;
        }
        return true;
    }
    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }
}