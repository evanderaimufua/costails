package com.example.cmpt370;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class Recipe extends IngredientContainer {

    // A list of recipe map's to hold the custom ingredients
   // private List<RecipeComponent> customIngredients;

    // this is the price that the user will enter as what they are currently selling the drink as
    // or what they think they should sell it at
    private double actualMenuPrice;

    // This is price that we will recommend to the user
    private double calculatedMenuPrice;

    // This is the calculated margin of each individual recipe(cocktail) stored for display purposes
    private double costOfGoodsSold;



    /**
     * Constructors for recipe class
     * RecipeComponent Interface makes it so the array list can hold both custom
     * and regular ingredients in the array list
     * Recipe needs no additional functionality at this time.
     * @param s type of ingredient
     * @param toString A string
     */
    public Recipe(String s, String toString){
        super();
    }

    public Recipe(String namein){super(namein);}

    public Recipe(){super();}

    @Override
    protected void doWrite(DBSerializationContext<DBObject> context) {
        super.doWrite(context);
        //context.write("customIngredients", super.getIngredients());
        context.write("actualMenuPrice", actualMenuPrice);
        context.write("calculatedMenuPrice", calculatedMenuPrice);
    }

    @Override
    protected void doRead(DBSerializationContext<DBObject> context) {
        super.doRead(context);
        //customIngredients = context.readObjectList("customIngredients");
        actualMenuPrice = context.readDouble("actualMenuPrice");
        calculatedMenuPrice = context.readDouble("calculatedMenuPrice");
    }

    public void addCustomIngredient(CustomIngredient ingredient, double amount){
        super.addIngredient(ingredient, amount);
    }

    public double getActualMenuPrice() {
        return actualMenuPrice;
    }

    public void setActualMenuPrice(double actualMenuPrice) {
        this.actualMenuPrice = actualMenuPrice;
        setCostOfGoodsSold();
    }

    public double getCalculatedMenuPrice() {
        return calculatedMenuPrice;
    }

    public void setCalculatedMenuPrice(double calculatedMenuPrice) {
        this.calculatedMenuPrice = calculatedMenuPrice;
    }

    public double getPriceDifference(){
        return actualMenuPrice - calculatedMenuPrice;
    }

    private void setCostOfGoodsSold(){
        this.costOfGoodsSold = this.getCost() / this.actualMenuPrice;
    }

    public double getCostOfGoodsSold(){
        return this.costOfGoodsSold;
    }

}
