/**
 * Author: Corinn Zieglgansberger
 */

package com.example.cmpt370;

/**
 * An initializer function that takes a serialization context and returns a DBObject object.
 */
public interface DBObjectInitializer<T> {
    T run(DBSerializationContext<T> context);
}
