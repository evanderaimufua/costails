/**
 * Author: Corinn Zieglgansberger
 */
package com.example.cmpt370;

/**
 *  A callback function that takes one parameter and returns nothing.
 */
public interface DBVoidCallback<T> {
    void run(T value);
}
