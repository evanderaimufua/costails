package com.example.cmpt370;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecipeList extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private RecipeAdapter adapter;
    private ArrayList<Recipe> recipeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_interface);
        mRecyclerView = findViewById(R.id.recyclerview_ingredients);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        recipeList = new ArrayList<>();
        adapter = new RecipeAdapter(this, recipeList, false);
        mRecyclerView.setAdapter(adapter);
        //read all objects from DB
        DBObject.getAllObjects(Recipe.class).then(objs -> {
            for (Recipe x : objs) recipeList.add(x);
            adapter.notifyDataSetChanged();
        });
    }
}
