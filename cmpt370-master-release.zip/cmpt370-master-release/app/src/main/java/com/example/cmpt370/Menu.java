package com.example.cmpt370;

import java.util.ArrayList;
import java.util.List;

public class Menu extends DBObject {

    private List<Recipe> recipeList = new ArrayList<>();
    private String name;

    private double actualMenuMargin, calculatedMargin, marginDifference;


    // Constructor
    public Menu(){
        super("MENU");
        this.actualMenuMargin = .30;
    }



    @Override
    protected void doWrite(DBSerializationContext<DBObject> context) {
        context.write("recipeList", recipeList);
        context.write("actualMenuMargin", actualMenuMargin);
        context.write("calculatedMargin", calculatedMargin);
        context.write("marginDifference", marginDifference);
    }

    @Override
    protected void doRead(DBSerializationContext<DBObject> context) {
        recipeList = context.readObjectList("recipeList");
        actualMenuMargin = context.readDouble("actualMenuMargin");
        calculatedMargin = context.readDouble("calculatedMargin");
        marginDifference = context.readDouble("marginDifference");
    }

    // Methods

    /**
     * Add a completed recipe to the menu page
     * @param recipe
     */
    public void addRecipe(Recipe recipe){
        this.recipeList.add(recipe);
        setDirty();
    }

    public void addRecipes(ArrayList<Recipe> recipes){
        this.recipeList.addAll(recipes);
        setDirty();
    }


    /**
     * To remove a recipe from the menu
     * @param recipeName A string with the name of the recipe
     */
    public void removeRecipe(String recipeName){
        int indexNumber = -1;

        for (Recipe recipe: recipeList){
            if (recipe.getName().equals(recipeName)){
                indexNumber = recipeList.indexOf(recipe);
            }
        }

        if (indexNumber != -1) {
            recipeList.remove(indexNumber);
        }

        setDirty();
    }

    /**
     * Calculate what the menu price of all recipes should be given
     * an inputted expected profit margin
     */
    public void applyProfitMargin(){
        for (Recipe recipe : recipeList){
            recipe.setCalculatedMenuPrice(recipe.getCost()*(100/this.calculatedMargin));
        }

        setDirty();
    }

    /**
     * To calculate the average margin of a given menu price
     */
    public void calculateActualMargin(){
        if (recipeList.size() >= 1) {
            for (Recipe recipe : recipeList) {
                this.actualMenuMargin += recipe.getCost() / recipe.getActualMenuPrice() ;
            }
            this.actualMenuMargin = this.actualMenuMargin / recipeList.size();
        }

        setDirty();
    }

    // Getters and setters

    public void setCalculatedMargin(double margin) {
        this.calculatedMargin = margin;
        setDirty();
    }

    public void setMarginDifference(){
        this.marginDifference = actualMenuMargin - calculatedMargin;
        setDirty();
    }

    public double getActualMenuMargin(){
        return this.actualMenuMargin;
    }

    public double getCalculatedMargin(){
        return this.calculatedMargin;
    }

    public double getMarginDifference(){
        return this.marginDifference;
    }

    public List<Recipe> getRecipeList(){
        return this.recipeList;
    }


}
