package com.example.cmpt370;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Author: Jessi
 *
 * Fragment responsible for adding menus to the database. See BrowseMenuFragment for selection details
 */
public class MenuAddFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private RecipeAdapter adapter;
    private EditText name;
    private ArrayList<Recipe> recipeList;
    private ArrayList<String> names, costs, recCosts;
    private Button add, find;
    private NavController navCntr;

    public MenuAddFragment(){
        recipeList = new ArrayList<>();
        names = new ArrayList<>();
        costs = new ArrayList<>();
        recCosts = new ArrayList<>();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_menu_creation, container, false);

        return view;
    }
    /**
     * Sets up the recycler veiw, which is responsible for dynamically displaying a list of
     * selected items from the corresponding browse fragment
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navCntr = Navigation.findNavController(view);
        mRecyclerView = view.findViewById(R.id.recyclerview_ingredients);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        adapter = new RecipeAdapter(view.getContext(), recipeList, false);
        mRecyclerView.setAdapter(adapter);

        //set the name and amount variables to point to the user entry fields.
        name = view.findViewById(R.id.edit_id1);
        add = (Button) view.findViewById(R.id.addcustom);
        find = (Button) view.findViewById(R.id.finding);

        add.setOnClickListener(this::OnClick_addMenu);
        find.setOnClickListener(this::OnClick_FindRecipes);

        //retrieves the selected items from browse fragment
        if(getArguments() != null){
            names = getArguments().getStringArrayList("names");
            costs = getArguments().getStringArrayList("costs");
            recCosts = getArguments().getStringArrayList("amount");
            for (int i = 0; i<names.size(); i++){
                Recipe recipe = new Recipe(names.get(i));
                recipe.setActualMenuPrice(Double.parseDouble(costs.get(i)));
                recipe.setCalculatedMenuPrice(Double.parseDouble(recCosts.get(i)));
                recipeList.add(recipe);
            }
        }
    }


    public void OnClick_addMenu(View view) {
        writeMenu();
    }

    private void writeMenu() throws RuntimeException{
        if (recipeList.isEmpty()){
            throw new RuntimeException("Please enter ingredients for the custom ingredient");
        }

        Menu menu = new Menu();
        menu.addRecipes(recipeList);
        Log.i("ingredient", menu.getName());
        menu.write();
        Log.i("firebase", "attempted to write");

    }

    public void OnClick_FindRecipes(View view) {
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("names", names);
        bundle.putStringArrayList("cost", costs);
        bundle.putStringArrayList("amount", recCosts);

        navCntr.navigate(R.id.action_AddCustom_to_browse, bundle);

    }
}
