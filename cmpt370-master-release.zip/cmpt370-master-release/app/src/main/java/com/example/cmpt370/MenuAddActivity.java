package com.example.cmpt370;


import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;


/**
 * Author: Jessi
 *
 * An Activity Container class to hold the associated fragments for adding a menu
 * The first (and home) fragment is found in the class MenuAddFragment
 * The second fragment
 * is contained in BrowseMenuFragment.java
 */

public class MenuAddActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_menu);
    }

}
