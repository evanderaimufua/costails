package com.example.cmpt370;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.fragment.app.FragmentActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


/**
 * Author: Jessi
 *
 * An Activity Container class to hold the associated fragments for adding a custom ingredient
 * The first (and home) fragment is found in the class CustomAddFragment
 * The second fragment (attached to the "find ingredients" button from fragment_custom_ingredient_creation)
 * is contained in BrowseFragment.java
 */

public class CustomAddActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_custom_ingr);
    }

}
