package com.example.cmpt370;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
/**
 * Author: Jessi
 *
 * Fragment responsible for adding recipes to the database. See BrowseRecipeFragment for selection details
 */
public class RecipeAddFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private RecipeMapAdapter adapter;
    private EditText name;
    private ArrayList<RecipeMap> ingredientsList;
    private ArrayList<String> names, costs, amounts;
    private Button add, find;
    private NavController navCntr;

    public RecipeAddFragment(){
        ingredientsList = new ArrayList<>();
        names = new ArrayList<>();
        costs = new ArrayList<>();
        amounts = new ArrayList<>();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_recipe_creation, container, false);

        return view;
    }

    /**
     * Sets up the recycler veiw, which is responsible for dynamically displaying a list of
     * selected items from the corresponding browse fragment
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navCntr = Navigation.findNavController(view);
        mRecyclerView = view.findViewById(R.id.recyclerview_ingredients);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        adapter = new RecipeMapAdapter(view.getContext(), ingredientsList);
        mRecyclerView.setAdapter(adapter);

        //set the name and amount variables to point to the user entry fields.
        name = view.findViewById(R.id.edit_id1);
        add = (Button) view.findViewById(R.id.addcustom);
        find = (Button) view.findViewById(R.id.finding);

        add.setOnClickListener(this::OnClick_addRecipe);
        find.setOnClickListener(this::OnClick_FindIngredients);
        //retrieves the selected items from browse fragments
        if(getArguments() != null){
            names = getArguments().getStringArrayList("names");
            costs = getArguments().getStringArrayList("costs");
            amounts = getArguments().getStringArrayList("amounts");
            for (int i = 0; i<names.size(); i++){
                Ingredient ingr = new Ingredient(names.get(i), Double.parseDouble(costs.get(i)));
                RecipeMap map = new RecipeMap(ingr, Double.parseDouble(amounts.get(i)));
                ingredientsList.add(map);
            }
        }
    }


    public void OnClick_addRecipe(View view) {
        writeRecipe();
    }

    private void writeRecipe() throws RuntimeException{
        if (ingredientsList.isEmpty()){
            throw new RuntimeException("Please enter ingredients for the custom ingredient");
        }
        if (name == null){
            throw new RuntimeException("Please enter a name");
        }
        Recipe recipe = new Recipe(name.getText().toString());
        recipe.addIngredients(ingredientsList);
        recipe.setActualMenuPrice(12.00);
        recipe.setCalculatedMenuPrice(0.0);
        Log.i("ingredient", recipe.getName());
        recipe.write();
        Log.i("firebase", "attempted to write");

    }

    public void OnClick_FindIngredients(View view) {
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("names", names);
        bundle.putStringArrayList("cost", costs);
        bundle.putStringArrayList("amount", amounts);

        navCntr.navigate(R.id.action_AddCustom_to_browse, bundle);

    }
}
