/**
 * Author: Corinn Zieglgansberger
 */

package com.example.cmpt370;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 *
 */
public class DBPromise<T> {

    private final Task<DataSnapshot> task;
    private final DBObjectInitializer<T> initializer;

    /**
     * Creates a new database promise that attempts to obtain all the data objects specified by
     * type.
     * @param type The type identifier of the data objects.
     * @param initializer An initializer function that creates/initializes a List of DBObject objects from a
     *                    serialization context.
     */
    public DBPromise(String type, DBObjectInitializer<T> initializer) {
        DatabaseReference root = FirebaseDatabase.getInstance().getReference();
        this.task = root.child(type).get();
        this.initializer = initializer;
    }

    /**
     * Creates a new database promise that attempts to obtain the data object specified by type and
     * id.
     * @param type The type identifier of the data object.
     * @param id The id of the data object.
     * @param initializer An initializer function that creates/initializes a DBObject from a
     *                    serialization context.
     */
    public DBPromise(String type, String id, DBObjectInitializer<T> initializer) {
        DatabaseReference root = FirebaseDatabase.getInstance().getReference();
        this.task = root.child(type).child(id).get();
        this.initializer = initializer;
    }

    /**
     * Registers a callback to be called once this promise is successfully fulfilled.
     * @param callback A DBResultCallback object.
     * @return This object for chaining.
     */
    DBPromise then(DBVoidCallback<T> callback) {
        DBSerializationContext context = new DBSerializationContext(initializer, callback);
        task.addOnCompleteListener(context.getListener());
        return this;
    }
}
