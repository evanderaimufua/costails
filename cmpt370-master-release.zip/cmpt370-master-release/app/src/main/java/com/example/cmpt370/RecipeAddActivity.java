package com.example.cmpt370;


import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;


/**
 * Author: Jessi
 *
 * An Activity Container class to hold the associated fragments for adding a custom ingredient
 * The first (and home) fragment is found in the class CustomAddFragment
 * The second fragment (attached to the "find ingredients" button from fragment_custom_ingredient_creation)
 * is contained in BrowseFragment.java
 */

public class RecipeAddActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_recipe);
    }

}
