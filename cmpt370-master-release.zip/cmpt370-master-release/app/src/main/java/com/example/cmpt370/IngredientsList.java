package com.example.cmpt370;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class IngredientsList extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private IngredientsAdapter adapter;
    private ArrayList<Ingredient> ingredientList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredients_list);
        mRecyclerView = findViewById(R.id.recyclerview_ingredients);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        ingredientList = new ArrayList<>();
        adapter = new IngredientsAdapter(this, ingredientList, false);
        mRecyclerView.setAdapter(adapter);
        //read all objects from DB
        DBObject.getAllObjects(Ingredient.class).then(objs -> {
            for (Ingredient x : objs) ingredientList.add(x);
            adapter.notifyDataSetChanged();
        });
        /*new DatabaseHelper(mDatabase).readAllIngredients(new DatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<Ingredient> ingredients, List<String> keys) {
                new RecylcerView_Config().setConfig(mRecyclerView, IngredientsList.this, ingredients, keys);

            }

            @Override
            public void DataIsInserted() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });*/
    }
}