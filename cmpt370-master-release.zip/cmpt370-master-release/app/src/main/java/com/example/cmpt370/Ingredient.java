package com.example.cmpt370;
import androidx.annotation.NonNull;


public class Ingredient extends RecipeComponent {


    private double unit_cost;
    private String type;


    /**Constructor
     *
     * @param name the name of the ingredient
     * @param cost the total cost of the ingredient
     * @param quantity the quantity of the ingredient at the given cost
     *                 (i.e. $10 for 200mL of syrup)
     */


    public Ingredient(String name, double cost, long quantity) throws RuntimeException {
        if (quantity <= 0){
            throw new RuntimeException("Invalid quantity input");
        }

        this.setName(name);
        this.unit_cost = cost/quantity;
    }


    /** alternaitve constructor for DB reads
     *
     * @param name name of the ingredient
     * @param unit_cost the unit cost calculated at user input time
     */
    public Ingredient(String name, double unit_cost) {
        this.setName(name);
        this.unit_cost=unit_cost;
    }

    public Ingredient(){};


    @Override
    protected void doWrite(DBSerializationContext<DBObject> context) {
        context.write("cost", unit_cost);
    }

    @Override
    protected void doRead(DBSerializationContext<DBObject> context) {
        unit_cost = context.readDouble("cost");
    }


    public void setCost(double cost, long quantity) {
        this.unit_cost = cost / quantity;
    }

    public double getCost() {
        return unit_cost;
    }

    @NonNull
    @Override
    public String toString() {
        return "Ingredient{" +
                "name='" +  getName() + '\n' +
                ", cost=" + unit_cost +
                '}';
    }
}
