# Cmpt370 Project
Welcome to group.exe's repository for the CMPT370 project. On the master-release branch, you'll find the final version of our application code.

## Description
Our software project is called costails - and it does exactly what you expect. Bar owners can enter their ingredients into a database, and use those ingredients to create cocktail recipes and menus - automatically tracking the costs of each drink and recommending mark-ups for profit.

## Installation
Begin by installing Android Studio Dolphin (https://developer.android.com/studio/). Once it has been installed, checkout the code from master-release, and open the code in Android Studio. Hit the gradle sync button. Once the files have synced, plug in your android device via usb, and click the launch app button.



